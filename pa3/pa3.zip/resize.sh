#/bin/bash

mogrify -resize x500 ${1}
